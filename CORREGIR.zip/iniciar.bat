@echo off
setlocal
cd /d "%~dp0"

title Gestor Proyectos - Inicio

echo ==========================================
echo       INICIAR GESTOR PROYECTOS
echo ==========================================
echo.

REM Comprobar que Python 3.14 esta instalado.
py -3.14 --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: No se encuentra Python 3.14.
    echo Instala Python 3.14 y vuelve a ejecutar este archivo.
    echo Puedes comprobar las versiones instaladas con: py --list
    pause
    exit /b 1
)

REM Comprobar los archivos principales del proyecto.
if not exist "requirements.txt" (
    echo ERROR: No se encuentra requirements.txt en la carpeta del proyecto.
    pause
    exit /b 1
)

if not exist "app\main.py" (
    echo ERROR: No se encuentra app\main.py.
    echo Comprueba que estes ejecutando este archivo desde la raiz del proyecto.
    pause
    exit /b 1
)

REM Comprobar el modulo que falta segun el error reportado.
if not exist "app\adapters\sqlite_repo.py" (
    echo ERROR: Falta app\adapters\sqlite_repo.py.
    echo.
    echo app\main.py intenta importar:
    echo from app.adapters.sqlite_repo import SQLiteRepository
    echo.
    echo Este archivo de inicio no puede reconstruir el modulo que falta.
    echo Recupera app\adapters\sqlite_repo.py desde el repositorio o desde
    echo la rama/commit donde se implemento, y confirma que este dentro de:
    echo %CD%\app\adapters\
    echo.
    echo Luego vuelve a ejecutar iniciar.bat.
    pause
    exit /b 1
)

REM Crear el entorno virtual si no existe.
if not exist ".venv\Scripts\python.exe" (
    echo Creando entorno virtual con Python 3.14...
    py -3.14 -m venv .venv
    if errorlevel 1 (
        echo ERROR: No se pudo crear el entorno virtual.
        pause
        exit /b 1
    )
)

echo.
echo Instalando/verificando dependencias...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Fallo la instalacion de dependencias.
    pause
    exit /b 1
)

echo.
echo Iniciando la aplicacion...
".venv\Scripts\python.exe" -m app.main

if errorlevel 1 (
    echo.
    echo La aplicacion termino con un error. Revisa el mensaje anterior.
)

echo.
pause
endlocal
